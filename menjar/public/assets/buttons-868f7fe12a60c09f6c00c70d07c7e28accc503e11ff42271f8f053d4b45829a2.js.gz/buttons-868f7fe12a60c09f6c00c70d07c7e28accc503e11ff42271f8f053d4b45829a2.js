$(document).ready(function(){
    $('#start_info').click(function(){
        $('#start_info_box').fadeOut("slow", function(){

        });
    });
});
